1. Using house/Real estate data predicting the value/price.
2. Both prediction's HTML file will be loaded in folder.
3. Multiple regression and KNN regression r2 score, Mean Squared Error and 
   Root Mean Squared Error has been founded.
4. tested with sample raw data. 
5. In python coding, you can find the data extraction, preprocessing data, exploratory data analysis, spliting data, modelling data.

